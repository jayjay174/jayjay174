<h1 align="center"> THE MEGALODON×BUG×BOT MULTI DEVICE </h1>
<p align="center">  

***
  
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=200&lines= MEGALODON×BUG×BOT;MULTI+DEVICE+WHATSAPP×Crash+BUG+BOT;CREATED+BY+DYBY+TRUE" alt="Typing SVG" /></a>
  </p>
    <img alt="MEGALODON_MD" width="700" height="400" src="https://files.catbox.moe/5skf1p.jpg">
<p align="center">
<p align="center">
<a href="https://github.com/DYBY-TRUE/MEGALODON_MD"><img title="Author" src="https://img.shields.io/badge/SPEED_MD-black?style=for-the-badge&logo=github"></a>
<p/>
<p align="center">
<a href="https://github.com/DYBY-TRUE?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/DYBY-TRUE?label=Followers&style=social"></a>
<a href="https://github.com/DYBY-TRUE/MEGALODON_MD/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/DYBY-TRUE/MEGALODON_MD?&style=social"></a>
<a href="https://github.com/DYBY-TRUE/MEGALODON_MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/DYBY-TRUE/MEGALODON_MD?style=social"></a>
<a href="https://github.com/DYBY-TRUE/MEGALODON_MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/DYBY-TRUE/MEGALODON_MD?label=Watching&style=social"></a>
  
***
1.`First STAR 🌟 This Repo ` And Then [`FORK`](https://github.com/DYBY-TRUE/MEGALODON_MD/fork) It
